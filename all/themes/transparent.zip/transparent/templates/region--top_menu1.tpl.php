<?php if ($content): ?>
    <?php print $content; ?>
<?php endif; ?>